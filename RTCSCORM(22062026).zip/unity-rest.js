var UnityRest = (function () {
  var config = {
    projectId: "99f57770-6792-4c65-a2c8-1ad5393c2b04",
    environmentId: "af2f7a7d-a0f1-41ae-95a7-6d19fd4429a0",
    environmentName: "production",

    serviceBasicAuth: "YWYxN2Q5NmItYzNiNi00MWY5LWE4MTYtNWVjMGVhNTkzNzg4OlRMdWd5RlBJTml0R29qc2VQd1pNMGRGVVhIX1BXSG1S",

    createSessionScriptName: "createsession1",
    startSessionScriptName: "StartSession1",
    sessionStatusScriptName: "sessionstatus1",
    completeSessionScriptName: "CompleteSession1",

    // Edit this before uploading the SCORM package.
    // Bridge Player ID format is: 4 random digits + first 3 safe chars here.
    // Example with "ABC": 4821ABC
    bridgeIdCustomString: "ABC"
  };

  var bearerToken = "";

  function validateConfig() {
    if (!config.projectId || !config.environmentId || !config.serviceBasicAuth) {
      throw new Error("Unity REST config is incomplete");
    }
  }

  function makeSafeId(rawId) {
    return String(rawId || "local-learner")
      .replace(/[^A-Za-z0-9_-]/g, "-")
      .substring(0, 64);
  }

  function makeSafeBridgeSuffix(value) {
    var safe = String(value || "ABC").replace(/[^A-Za-z0-9]/g, "").toUpperCase();
    return (safe + "XXX").substring(0, 3);
  }

  function makeRandomFourDigits() {
    return String(Math.floor(1000 + Math.random() * 9000));
  }

  async function exchangeBearerToken() {
    validateConfig();

    if (bearerToken) return bearerToken;

    var url = "https://services.api.unity.com/auth/v1/token-exchange?projectId=" +
      encodeURIComponent(config.projectId) +
      "&environmentId=" +
      encodeURIComponent(config.environmentId);

    var response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Basic " + config.serviceBasicAuth
      },
      body: "{}"
    });

    if (!response.ok) {
      throw new Error("Token exchange failed: HTTP " + response.status + " " + await response.text());
    }

    var data = await response.json();
    bearerToken = data.accessToken || data.access_token || data.token || data.idToken || "";

    if (!bearerToken) {
      throw new Error("Token exchange response did not include an access token");
    }

    return bearerToken;
  }

  async function callScript(scriptName, params) {
    var token = await exchangeBearerToken();
    var url = "https://cloud-code.services.api.unity.com/v1/projects/" +
      encodeURIComponent(config.projectId) +
      "/scripts/" +
      encodeURIComponent(scriptName);

    var response = await fetch(url, {
      method: "POST",
      headers: {
        "Authorization": "Bearer " + token,
        "Content-Type": "application/json",
        "UnityEnvironment": config.environmentName
      },
      body: JSON.stringify({ params: params || {} })
    });

    if (!response.ok) {
      throw new Error(scriptName + " failed: HTTP " + response.status + " " + await response.text());
    }

    var data = await response.json();
    return data.output === undefined ? data : data.output;
  }

  function makeBridgePlayerId() {
    var existing = sessionStorage.getItem("bridgePlayerId");
    if (existing) return existing;

    var bridgePlayerId = makeRandomFourDigits() + makeSafeBridgeSuffix(config.bridgeIdCustomString);
    sessionStorage.setItem("bridgePlayerId", bridgePlayerId);
    return bridgePlayerId;
  }

  async function createSession(args) {
    return callScript(config.createSessionScriptName, args);
  }

  async function startSession(args) {
    return callScript(config.startSessionScriptName, args);
  }

  async function sessionStatus(args) {
    return callScript(config.sessionStatusScriptName, args);
  }

  async function completeSession(args) {
    return callScript(config.completeSessionScriptName, args);
  }

  return {
    config: config,
    exchangeBearerToken: exchangeBearerToken,
    callScript: callScript,
    makeBridgePlayerId: makeBridgePlayerId,
    createSession: createSession,
    startSession: startSession,
    sessionStatus: sessionStatus,
    completeSession: completeSession
  };
})();
