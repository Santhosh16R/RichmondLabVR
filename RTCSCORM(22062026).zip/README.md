# SCORM REST Package

This is a standalone SCORM package that calls Unity REST APIs directly.

It mirrors the curl flow:

1. `POST https://services.api.unity.com/auth/v1/token-exchange`
2. `POST https://cloud-code.services.api.unity.com/v1/projects/{projectId}/scripts/{scriptName}`

## Files

- `bridge.html`
- `imsmanifest.xml`
- `scorm.js`
- `unity-rest.js`
- `qrcode.min.js`
- `style.css`

Zip the contents of this folder when uploading to an LMS or SCORM Cloud.

## Config

Edit `unity-rest.js`:

```js
projectId: "99f57770-6792-4c65-a2c8-1ad5393c2b04",
environmentId: "af2f7a7d-a0f1-41ae-95a7-6d19fd4429a0",
environmentName: "production",
serviceBasicAuth: "...",
bridgeIdCustomString: "ABC"
```

`serviceBasicAuth` is the base64 part from:

```text
Authorization: Basic <base64>
```

`bridgeIdCustomString` is the custom 3-character code you set before uploading the SCORM package. The displayed Bridge Player ID becomes:

```text
4 random digits + bridgeIdCustomString
```

Example:

```text
4821ABC
```

## Cloud Code Script Names

Default names:

```js
createSessionScriptName: "createsession",
startSessionScriptName: "StartSession",
sessionStatusScriptName: "sessionstatus",
completeSessionScriptName: "CompleteSession",
bridgeIdCustomString: "ABC"
```

Match these to the exact script names deployed in Unity Cloud Code.
