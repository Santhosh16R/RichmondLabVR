var UnityCloud = (function () {
  var config = {
    projectId: "99f57770-6792-4c65-a2c8-1ad5393c2b04",
    environmentId: "af2f7a7d-a0f1-41ae-95a7-6d19fd4429a0",
    environmentName: "production",

    // Prototype only. This is the base64 value from:
    // Authorization: Basic <base64>
    // Do not use this approach for production SCORM packages.
    serviceBasicAuth: "YWYxN2Q5NmItYzNiNi00MWY5LWE4MTYtNWVjMGVhNTkzNzg4OlRMdWd5RlBJTml0R29qc2VQd1pNMGRGVVhIX1BXSG1S",

    createSessionScriptName: "createsession1",
    sessionStatusScriptName: "sessionstatus1",
    completeSessionScriptName: "CompleteSession1",

    // Edit this before uploading the SCORM package.
    // Shared token format is: 4 random digits + first 3 safe chars here.
    // Example with "ABC": 4821ABC
    bridgeIdCustomString: "ABC"
  };

  var auth = null;

  function requireConfig() {
    if (config.projectId.indexOf("YOUR_") === 0 || config.environmentId.indexOf("YOUR_") === 0) {
      throw new Error("Set projectId and environmentId in unity-cloud.js");
    }

    if (!config.serviceBasicAuth || config.serviceBasicAuth.indexOf("PASTE_") === 0) {
      throw new Error("Set serviceBasicAuth in unity-cloud.js");
    }

    if (config.serviceBasicAuth.indexOf(".") !== -1) {
      throw new Error("serviceBasicAuth contains a bearer/JWT token. Paste the base64 value from Authorization: Basic instead.");
    }
  }

  function makeSafeId(rawId) {
    return String(rawId || "local-learner")
      .replace(/[^A-Za-z0-9_-]/g, "-")
      .substring(0, 64);
  }

  function makeSafeBridgeSuffix(value) {
    var safe = String(value || "ABC").replace(/[^A-Za-z0-9]/g, "").toUpperCase();
    return (safe + "XXX").substring(0, 3);
  }

  function makeRandomFourDigits() {
    return String(Math.floor(1000 + Math.random() * 9000));
  }

  function makeSharedBridgeToken() {
    var existing = sessionStorage.getItem("sharedBridgeToken");
    if (existing) return existing;

    var token = makeRandomFourDigits() + makeSafeBridgeSuffix(config.bridgeIdCustomString);
    sessionStorage.setItem("sharedBridgeToken", token);
    return token;
  }

  function saveAuth(nextAuth) {
    auth = nextAuth;
    sessionStorage.setItem("unityServiceAuth", JSON.stringify(nextAuth));
  }

  function loadAuth() {
    if (auth) return auth;

    try {
      var cached = JSON.parse(sessionStorage.getItem("unityServiceAuth") || "null");
      if (cached && cached.accessToken) {
        auth = cached;
        return auth;
      }
    } catch (err) {
      sessionStorage.removeItem("unityServiceAuth");
    }

    return null;
  }

  async function exchangeServiceToken() {
    requireConfig();

    var cached = loadAuth();
    if (cached) return cached;

    var url = "https://services.api.unity.com/auth/v1/token-exchange?projectId=" +
      encodeURIComponent(config.projectId) +
      "&environmentId=" +
      encodeURIComponent(config.environmentId);

    var response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Basic " + config.serviceBasicAuth
      },
      body: "{}"
    });

    if (!response.ok) {
      var errorText = await response.text();
      throw new Error("Unity token exchange failed: HTTP " + response.status + " " + errorText);
    }

    var data = await response.json();
    var accessToken = data.accessToken || data.access_token || data.token || data.idToken;

    if (!accessToken) {
      throw new Error("Unity token exchange response did not include an access token");
    }

    saveAuth({ accessToken: accessToken });
    return auth;
  }

  async function authenticateBridge(learnerId) {
    var currentAuth = await exchangeServiceToken();
    currentAuth.learnerBridgeId = "scorm-" + makeSafeId(learnerId);
    currentAuth.bridgePlayerId = makeSharedBridgeToken();
    saveAuth(currentAuth);
    return currentAuth;
  }

  async function callScript(scriptName, params) {
    requireConfig();

    var currentAuth = loadAuth() || await exchangeServiceToken();
    var url = "https://cloud-code.services.api.unity.com/v1/projects/" +
      encodeURIComponent(config.projectId) +
      "/scripts/" +
      encodeURIComponent(scriptName);

    var response = await fetch(url, {
      method: "POST",
      headers: {
        "Authorization": "Bearer " + currentAuth.accessToken,
        "Content-Type": "application/json",
        "UnityEnvironment": config.environmentName
      },
      body: JSON.stringify({ params: params || {} })
    });

    if (!response.ok) {
      var errorText = await response.text();
      throw new Error("Cloud Code " + scriptName + " failed: HTTP " + response.status + " " + errorText);
    }

    var data = await response.json();
    return data.output === undefined ? data : data.output;
  }

  return {
    config: config,
    authenticateBridge: authenticateBridge,
    callScript: callScript
  };
})();
