/**
 * RichMondLab SCORM 2004 API Wrapper
 * Handles all communication between the SCO and the LMS
 */

var SCORM = (function () {
  var API = null;
  var initialized = false;
  var sessionStart = null;

  // ── Find the SCORM 2004 API ──────────────────────────────────────────────
  function findAPI(win) {
    var attempts = 0;
    while (win) {
      if (win.API_1484_11) return win.API_1484_11;
      
      // If we hit the top window and still no API, check the opener (for new windows)
      if (win.parent && win.parent !== win) {
        win = win.parent;
      } else if (win.opener) {
        win = win.opener;
      } else {
        break;
      }
      
      attempts++;
      if (attempts > 10) break;
    }
    return null;
  }

  function getAPI() {
    if (API) return API;
    API = findAPI(window);
    if (!API && window.opener) API = findAPI(window.opener);
    return API;
  }

  // ── Lifecycle ────────────────────────────────────────────────────────────
  function initialize() {
    var api = getAPI();
    if (!api) { console.warn("[SCORM] No API found"); return false; }
    var result = api.Initialize("");
    if (result === "true" || result === true) {
      initialized = true;
      sessionStart = new Date();
      console.log("[SCORM] Initialized");
      // Set initial state
      setValue("cmi.completion_status", "incomplete");
      setValue("cmi.success_status", "unknown");
      return true;
    }
    console.error("[SCORM] Initialize failed:", api.GetLastError());
    return false;
  }

  function terminate() {
    if (!initialized) return;
    commitSessionTime();
    var api = getAPI();
    if (api) {
      api.Commit("");
      api.Terminate("");
      initialized = false;
      console.log("[SCORM] Terminated");
    }
  }

  // ── Data Model ───────────────────────────────────────────────────────────
  function setValue(element, value) {
    var api = getAPI();
    if (!api || !initialized) return false;
    var result = api.SetValue(element, String(value));
    if (result !== "true" && result !== true) {
      console.warn("[SCORM] SetValue failed for", element, "| Error:", api.GetLastError());
    }
    return result === "true" || result === true;
  }

  function getValue(element) {
    var api = getAPI();
    if (!api || !initialized) return "";
    return api.GetValue(element);
  }

  function commit() {
    var api = getAPI();
    if (!api || !initialized) return;
    api.Commit("");
  }

  // ── Time Helpers (ISO 8601 Duration) ─────────────────────────────────────
  function secondsToISO(seconds) {
    seconds = Math.round(seconds);
    var h = Math.floor(seconds / 3600);
    var m = Math.floor((seconds % 3600) / 60);
    var s = seconds % 60;
    return "PT" + h + "H" + m + "M" + s + "S";
  }

  function commitSessionTime() {
    if (!sessionStart) return;
    var elapsed = (new Date() - sessionStart) / 1000;
    setValue("cmi.session_time", secondsToISO(elapsed));
  }

  // ── Public API ───────────────────────────────────────────────────────────

  /**
   * Called by Unity (via postMessage or direct call) to report results.
   * @param {Object} data - { score: 0-100, passed: bool, completed: bool, timeSeconds: number }
   */
  function reportResults(data) {
    console.log("[SCORM] Reporting results:", data);

    if (typeof data.score === "number") {
      setValue("cmi.score.raw", data.score);
      setValue("cmi.score.min", 0);
      setValue("cmi.score.max", 100);
      setValue("cmi.score.scaled", (data.score / 100).toFixed(2));
    }

    if (typeof data.passed === "boolean") {
      setValue("cmi.success_status", data.passed ? "passed" : "failed");
    }

    if (typeof data.timeSeconds === "number") {
      setValue("cmi.session_time", secondsToISO(data.timeSeconds));
    }

    if (data.completed === true) {
      setValue("cmi.completion_status", "completed");
      setValue("cmi.progress_measure", "1");
    }

    commit();
    console.log("[SCORM] Results committed.");
  }

  // Listen for postMessage from Unity WebGL or external source
  window.addEventListener("message", function (event) {
    try {
      var msg = typeof event.data === "string" ? JSON.parse(event.data) : event.data;
      if (msg && msg.type === "RICHMONDLAB_RESULTS") {
        reportResults(msg.payload);
        if (typeof window.onScormResultsReceived === "function") {
          window.onScormResultsReceived(msg.payload);
        }
      }
    } catch (e) {
      // Not our message
    }
  });

  // Also expose globally so Unity JSLib can call window.SCORM.reportResults(...)
  return {
    initialize: initialize,
    terminate: terminate,
    setValue: setValue,
    getValue: getValue,
    commit: commit,
    reportResults: reportResults
  };
})();

// Auto-init when DOM is ready
window.addEventListener("load", function () {
  SCORM.initialize();
});

// Auto-terminate on unload
window.addEventListener("beforeunload", function () {
  SCORM.terminate();
});
