var SCORM = (function () {
  var api = null;
  var initialized = false;
  var sessionStart = null;
  var completed = false;

  function findAPI(win) {
    var attempts = 0;

    while (win && attempts < 20) {
      if (win.API_1484_11) return win.API_1484_11;

      if (win.parent && win.parent !== win) {
        win = win.parent;
      } else if (win.opener) {
        win = win.opener;
      } else {
        break;
      }

      attempts += 1;
    }

    return null;
  }

  function getAPI() {
    if (api) return api;
    api = findAPI(window);
    return api;
  }

  function initialize() {
    var scormApi = getAPI();
    if (!scormApi) return false;

    var result = scormApi.Initialize("");
    initialized = result === true || result === "true";
    if (initialized) sessionStart = new Date();
    return initialized;
  }

  function setValue(key, value) {
    var scormApi = getAPI();
    if (!scormApi || !initialized) return false;
    var result = scormApi.SetValue(key, String(value));
    return result === true || result === "true";
  }

  function getValue(key) {
    var scormApi = getAPI();
    if (!scormApi || !initialized) return "";
    return scormApi.GetValue(key) || "";
  }

  function commit() {
    var scormApi = getAPI();
    if (!scormApi || !initialized) return false;
    var result = scormApi.Commit("");
    return result === true || result === "true";
  }

  function secondsToDuration(seconds) {
    var rounded = Math.max(0, Math.round(seconds || 0));
    var hours = Math.floor(rounded / 3600);
    var minutes = Math.floor((rounded % 3600) / 60);
    var secs = rounded % 60;
    return "PT" + hours + "H" + minutes + "M" + secs + "S";
  }

  function reportCompletion(result) {
    var score = Number(result.score || 0);
    var passed = result.passed === true || result.passed === "true";
    var elapsedSeconds = sessionStart ? (new Date() - sessionStart) / 1000 : 0;

    completed = true;
    setValue("cmi.score.raw", score);
    setValue("cmi.score.min", 0);
    setValue("cmi.score.max", 100);
    setValue("cmi.score.scaled", Math.max(0, Math.min(1, score / 100)));
    setValue("cmi.completion_status", "completed");
    setValue("cmi.success_status", passed ? "passed" : "failed");
    setValue("cmi.progress_measure", 1);
    setValue("cmi.session_time", secondsToDuration(elapsedSeconds));
    setValue("cmi.exit", "normal");

    if (result.customData !== undefined && result.customData !== null) {
      setValue("cmi.suspend_data", JSON.stringify(result.customData));
    }

    commit();
  }

  function reportIncomplete() {
    var elapsedSeconds = sessionStart ? (new Date() - sessionStart) / 1000 : 0;

    if (completed) return;

    setValue("cmi.completion_status", "incomplete");
    setValue("cmi.success_status", "unknown");
    setValue("cmi.progress_measure", 0);
    setValue("cmi.session_time", secondsToDuration(elapsedSeconds));
    setValue("cmi.exit", "suspend");
    commit();
  }

  function abandonIncomplete() {
    if (!initialized || completed) return false;

    reportIncomplete();
    return terminate();
  }

  function terminate() {
    var scormApi = getAPI();
    if (!scormApi || !initialized) return false;
    commit();
    var result = scormApi.Terminate("");
    initialized = false;
    return result === true || result === "true";
  }

  return {
    initialize: initialize,
    getValue: getValue,
    setValue: setValue,
    commit: commit,
    reportCompletion: reportCompletion,
    reportIncomplete: reportIncomplete,
    abandonIncomplete: abandonIncomplete,
    terminate: terminate
  };
})();
