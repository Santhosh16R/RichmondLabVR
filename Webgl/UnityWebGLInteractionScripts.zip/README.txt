Unity WebGL First-Person Interaction Scripts

Files:
- WebGLFirstPersonController.cs
- WebGLPlayerInteraction.cs
- PickupObject.cs
- InteractableObject.cs

Controls:
- WASD: Move
- Mouse: Look
- Left Click: Lock cursor
- Escape: Unlock cursor
- F: Pick up / place / drop
- E: Interact

Basic Setup:
1. Create a Player GameObject.
2. Add CharacterController.
3. Add WebGLFirstPersonController.
4. Add WebGLPlayerInteraction.
5. Add a Camera as a child of Player.
6. Add an empty HoldPoint as a child of Camera, e.g. local position (0, -0.2, 1.5).
7. Assign Camera and HoldPoint to WebGLPlayerInteraction.
8. For pickup objects, add Collider + Rigidbody + PickupObject.
9. For interactive objects, add Collider + InteractableObject.
10. Hook UnityEvents in the Inspector.

These scripts use Unity's classic Input Manager and standard physics APIs, so they are suitable for Unity WebGL builds.
