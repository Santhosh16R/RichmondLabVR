using UnityEngine;

public class WebGLPlayerInteraction : MonoBehaviour
{
    [Header("References")]
    public Camera playerCamera;
    public Transform holdPoint;

    [Header("Interaction")]
    public float interactionDistance = 4f;
    public LayerMask interactionMask = ~0;

    [Header("Controls")]
    public KeyCode pickupKey = KeyCode.F;
    public KeyCode interactionKey = KeyCode.E;

    [Header("Placement")]
    public float placementOffset = 0.02f;

    private PickupObject heldObject;

    void Start()
    {
        if (playerCamera == null)
            playerCamera = Camera.main;
    }

    void Update()
    {
        if (playerCamera == null || holdPoint == null)
            return;

        if (Input.GetKeyDown(pickupKey))
        {
            if (heldObject == null)
                TryPickup();
            else
                TryPlaceObject();
        }

        if (Input.GetKeyDown(interactionKey))
        {
            TryInteract();
        }
    }

    void TryPickup()
    {
        Ray ray = new Ray(
            playerCamera.transform.position,
            playerCamera.transform.forward
        );

        if (Physics.Raycast(
            ray,
            out RaycastHit hit,
            interactionDistance,
            interactionMask))
        {
            PickupObject pickup =
                hit.collider.GetComponentInParent<PickupObject>();

            if (pickup != null)
                Pickup(pickup);
        }
    }

    void Pickup(PickupObject pickup)
    {
        heldObject = pickup;

        pickup.OnPickedUp();

        pickup.transform.SetParent(holdPoint);
        pickup.transform.localPosition = Vector3.zero;
        pickup.transform.localRotation = Quaternion.identity;

        if (pickup.Rigidbody != null)
        {
            pickup.Rigidbody.isKinematic = true;
            pickup.Rigidbody.useGravity = false;
        }

        foreach (Collider col in pickup.GetComponentsInChildren<Collider>())
            col.enabled = false;
    }

    void TryPlaceObject()
    {
        Ray ray = new Ray(
            playerCamera.transform.position,
            playerCamera.transform.forward
        );

        if (Physics.Raycast(
            ray,
            out RaycastHit hit,
            interactionDistance,
            interactionMask))
        {
            PlaceObject(hit);
        }
        else
        {
            DropObject();
        }
    }

    void PlaceObject(RaycastHit hit)
    {
        PickupObject objectToPlace = heldObject;
        objectToPlace.transform.SetParent(null);

        objectToPlace.transform.position =
            hit.point + hit.normal * placementOffset;

        objectToPlace.transform.rotation =
            Quaternion.FromToRotation(Vector3.up, hit.normal);

        EnableObjectPhysics(objectToPlace);

        objectToPlace.OnPlaced(hit.collider.gameObject);

        heldObject = null;
    }

    void DropObject()
    {
        PickupObject objectToDrop = heldObject;

        objectToDrop.transform.SetParent(null);

        EnableObjectPhysics(objectToDrop);

        objectToDrop.OnDropped();

        heldObject = null;
    }

    void EnableObjectPhysics(PickupObject pickup)
    {
        foreach (Collider col in pickup.GetComponentsInChildren<Collider>())
            col.enabled = true;

        if (pickup.Rigidbody != null)
        {
            pickup.Rigidbody.isKinematic = false;
            pickup.Rigidbody.useGravity = true;
        }
    }

    void TryInteract()
    {
        Ray ray = new Ray(
            playerCamera.transform.position,
            playerCamera.transform.forward
        );

        if (Physics.Raycast(
            ray,
            out RaycastHit hit,
            interactionDistance,
            interactionMask))
        {
            InteractableObject interactable =
                hit.collider.GetComponentInParent<InteractableObject>();

            if (interactable != null)
                interactable.Interact();
        }
    }
}
