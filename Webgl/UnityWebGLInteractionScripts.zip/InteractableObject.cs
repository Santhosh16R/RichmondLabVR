using UnityEngine;
using UnityEngine.Events;

public class InteractableObject : MonoBehaviour
{
    [Header("Interaction")]
    public UnityEvent onInteract;

    public void Interact()
    {
        Debug.Log("Interacted with: " + gameObject.name);
        onInteract?.Invoke();
    }
}
