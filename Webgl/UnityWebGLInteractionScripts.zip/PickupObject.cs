using UnityEngine;
using UnityEngine.Events;

public class PickupObject : MonoBehaviour
{
    [Header("References")]
    public Rigidbody Rigidbody;

    [Header("Events")]
    public UnityEvent onPickedUp;
    public UnityEvent onDropped;

    [Header("Placement")]
    public UnityEvent<GameObject> onPlaced;

    void Awake()
    {
        if (Rigidbody == null)
            Rigidbody = GetComponent<Rigidbody>();
    }

    public void OnPickedUp()
    {
        onPickedUp?.Invoke();
    }

    public void OnDropped()
    {
        onDropped?.Invoke();
    }

    public void OnPlaced(GameObject target)
    {
        onPlaced?.Invoke(target);
    }
}
