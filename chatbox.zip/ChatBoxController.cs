// ================================================================
// ChatBoxController.cs
// Unity UI Toolkit – Chat UI with Mic (Speech-to-Text) + REST AI API
//
// SETUP:
//   1. Attach this script to a GameObject that has a UIDocument component.
//   2. Assign the UIDocument's Source Asset to ChatBox.uxml.
//   3. Fill in AI_API_URL and AI_API_KEY in the Inspector.
//   4. Optionally fill STT_API_URL / STT_API_KEY for speech recognition.
//
// SPEECH-TO-TEXT:
//   Uses Unity's Microphone class to record audio, converts it to
//   WAV bytes, and POSTs to your STT endpoint (e.g. OpenAI Whisper,
//   Azure Speech-to-Text, or any compatible REST endpoint).
//   The transcribed text is placed into the chat input field.
//
// AI REPLY:
//   Sends the full conversation history to your AI REST endpoint
//   and streams/receives the assistant reply, then renders it as
//   an AI bubble.
// ================================================================

using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.UIElements;
using UnityEngine.Networking;

public class ChatBoxController : MonoBehaviour
{
    // ── Inspector Fields ──────────────────────────────────────────
    [Header("UI Document")]
    public UIDocument uiDocument;

    [Header("AI REST API")]
    [Tooltip("Your AI chat completion endpoint, e.g. https://api.openai.com/v1/chat/completions")]
    public string aiApiUrl = "https://api.openai.com/v1/chat/completions";
    public string aiApiKey = "YOUR_AI_API_KEY";
    public string aiModel  = "gpt-4o-mini";

    [Header("Speech-to-Text REST API")]
    [Tooltip("STT endpoint, e.g. https://api.openai.com/v1/audio/transcriptions (Whisper)")]
    public string sttApiUrl = "https://api.openai.com/v1/audio/transcriptions";
    public string sttApiKey = "YOUR_STT_API_KEY"; // Leave empty to reuse aiApiKey
    public string sttModel  = "whisper-1";

    [Header("Microphone")]
    [Tooltip("Max recording seconds. 0 = use first available mic.")]
    public int maxRecordingSeconds = 30;
    public int recordingFrequency  = 16000;

    // ── Private State ─────────────────────────────────────────────
    private ScrollView       _chatScroll;
    private VisualElement    _messagesContainer;
    private TextField        _chatInput;
    private Button           _micButton;
    private Button           _sendButton;
    private VisualElement    _typingIndicator;

    private bool             _isRecording = false;
    private AudioClip        _recordingClip;
    private string           _micDevice;

    // Conversation history for multi-turn context
    private readonly List<ChatMessage> _history = new List<ChatMessage>();

    // ── Unity Lifecycle ───────────────────────────────────────────
    void OnEnable()
    {
        var root = uiDocument.rootVisualElement;

        _chatScroll        = root.Q<ScrollView>("chat-scroll");
        _messagesContainer = root.Q<VisualElement>("messages-container");
        _chatInput         = root.Q<TextField>("chat-input");
        _micButton         = root.Q<Button>("mic-button");
        _sendButton        = root.Q<Button>("send-button");
        _typingIndicator   = root.Q<VisualElement>("typing-indicator");

        _micButton.clicked  += OnMicButtonClicked;
        _sendButton.clicked += OnSendButtonClicked;

        // Allow Enter key to send
        _chatInput.RegisterCallback<KeyDownEvent>(evt =>
        {
            if (evt.keyCode == KeyCode.Return || evt.keyCode == KeyCode.KeypadEnter)
                OnSendButtonClicked();
        });

        // Pick first available mic
        if (Microphone.devices.Length > 0)
            _micDevice = Microphone.devices[0];
        else
            Debug.LogWarning("[ChatBox] No microphone detected.");

        // Optional: show a welcome message
        AddAIBubble("Hello! How can I help you today?");
    }

    void OnDisable()
    {
        if (_micButton  != null) _micButton.clicked  -= OnMicButtonClicked;
        if (_sendButton != null) _sendButton.clicked -= OnSendButtonClicked;
        StopRecording();
    }

    // ── Send Button ───────────────────────────────────────────────
    private void OnSendButtonClicked()
    {
        string text = _chatInput.value.Trim();
        if (string.IsNullOrEmpty(text)) return;

        _chatInput.value = string.Empty;
        SendUserMessage(text);
    }

    // ── Mic Button ────────────────────────────────────────────────
    private void OnMicButtonClicked()
    {
        if (_isRecording)
            StopRecordingAndTranscribe();
        else
            StartRecording();
    }

    private void StartRecording()
    {
        if (string.IsNullOrEmpty(_micDevice))
        {
            Debug.LogError("[ChatBox] No microphone available.");
            return;
        }

        _isRecording   = true;
        _recordingClip = Microphone.Start(_micDevice, false, maxRecordingSeconds, recordingFrequency);
        _micButton.AddToClassList("mic-button--recording");
        Debug.Log("[ChatBox] Recording started...");
    }

    private void StopRecording()
    {
        if (!_isRecording) return;
        Microphone.End(_micDevice);
        _isRecording = false;
        _micButton.RemoveFromClassList("mic-button--recording");
    }

    private void StopRecordingAndTranscribe()
    {
        // Capture recorded position before stopping
        int position = Microphone.GetPosition(_micDevice);
        Microphone.End(_micDevice);
        _isRecording = false;
        _micButton.RemoveFromClassList("mic-button--recording");

        if (_recordingClip == null || position == 0)
        {
            Debug.LogWarning("[ChatBox] Recording was empty.");
            return;
        }

        // Trim the clip to the actual recorded length
        AudioClip trimmed = TrimAudioClip(_recordingClip, position);
        byte[] wavBytes   = AudioClipToWav(trimmed);

        StartCoroutine(TranscribeAudio(wavBytes));
    }

    // ── STT Coroutine ─────────────────────────────────────────────
    private IEnumerator TranscribeAudio(byte[] wavBytes)
    {
        SetInputEnabled(false);
        ShowTyping(true);

        string key = string.IsNullOrEmpty(sttApiKey) ? aiApiKey : sttApiKey;

        WWWForm form = new WWWForm();
        form.AddBinaryData("file", wavBytes, "audio.wav", "audio/wav");
        form.AddField("model", sttModel);

        using UnityWebRequest req = UnityWebRequest.Post(sttApiUrl, form);
        req.SetRequestHeader("Authorization", $"Bearer {key}");
        yield return req.SendWebRequest();

        ShowTyping(false);
        SetInputEnabled(true);

        if (req.result != UnityWebRequest.Result.Success)
        {
            Debug.LogError($"[ChatBox] STT error: {req.error}\n{req.downloadHandler.text}");
            yield break;
        }

        // Parse Whisper-style response: { "text": "..." }
        string json       = req.downloadHandler.text;
        STTResponse sttRes = JsonUtility.FromJson<STTResponse>(json);
        string transcript  = sttRes?.text?.Trim();

        if (!string.IsNullOrEmpty(transcript))
        {
            _chatInput.value = transcript;
            // Auto-send after transcription (comment out if you want user to review first)
            SendUserMessage(transcript);
            _chatInput.value = string.Empty;
        }
    }

    // ── Core Message Flow ─────────────────────────────────────────
    private void SendUserMessage(string text)
    {
        AddUserBubble(text);
        _history.Add(new ChatMessage { role = "user", content = text });
        StartCoroutine(FetchAIReply());
    }

    private IEnumerator FetchAIReply()
    {
        SetInputEnabled(false);
        ShowTyping(true);

        // Build request body
        var requestBody = new ChatRequest
        {
            model    = aiModel,
            messages = _history.ToArray()
        };
        string jsonBody = JsonUtility.ToJson(requestBody);
        byte[] bodyRaw  = Encoding.UTF8.GetBytes(jsonBody);

        using UnityWebRequest req = new UnityWebRequest(aiApiUrl, "POST");
        req.uploadHandler   = new UploadHandlerRaw(bodyRaw);
        req.downloadHandler = new DownloadHandlerBuffer();
        req.SetRequestHeader("Content-Type",  "application/json");
        req.SetRequestHeader("Authorization", $"Bearer {aiApiKey}");

        yield return req.SendWebRequest();

        ShowTyping(false);
        SetInputEnabled(true);

        if (req.result != UnityWebRequest.Result.Success)
        {
            Debug.LogError($"[ChatBox] AI API error: {req.error}\n{req.downloadHandler.text}");
            AddAIBubble("⚠️ Sorry, I couldn't reach the server. Please try again.");
            yield break;
        }

        // Parse OpenAI-compatible response
        string responseJson = req.downloadHandler.text;
        ChatResponse chatRes = JsonUtility.FromJson<ChatResponse>(responseJson);
        string reply = chatRes?.choices?[0]?.message?.content?.Trim();

        if (string.IsNullOrEmpty(reply))
        {
            AddAIBubble("⚠️ Received an empty response.");
            yield break;
        }

        _history.Add(new ChatMessage { role = "assistant", content = reply });
        AddAIBubble(reply);
    }

    // ── UI Bubble Builders ────────────────────────────────────────
    private void AddUserBubble(string text)
    {
        var row = new VisualElement();
        row.AddToClassList("msg-row-user");

        var bubble = new VisualElement();
        bubble.AddToClassList("bubble-user");

        var label = new Label(text);
        label.AddToClassList("bubble-text");

        var timestamp = new Label(DateTime.Now.ToString("HH:mm"));
        timestamp.AddToClassList("bubble-timestamp");

        bubble.Add(label);
        bubble.Add(timestamp);
        row.Add(bubble);
        _messagesContainer.Add(row);

        ScrollToBottom();
    }

    private void AddAIBubble(string text)
    {
        var row = new VisualElement();
        row.AddToClassList("msg-row-ai");

        var bubble = new VisualElement();
        bubble.AddToClassList("bubble-ai");

        var label = new Label(text);
        label.AddToClassList("bubble-text");

        var timestamp = new Label(DateTime.Now.ToString("HH:mm"));
        timestamp.AddToClassList("bubble-timestamp");

        bubble.Add(label);
        bubble.Add(timestamp);
        row.Add(bubble);
        _messagesContainer.Add(row);

        ScrollToBottom();
    }

    // ── Helpers ───────────────────────────────────────────────────
    private void ShowTyping(bool show)
    {
        if (show) _typingIndicator.RemoveFromClassList("hidden");
        else      _typingIndicator.AddToClassList("hidden");
    }

    private void SetInputEnabled(bool enabled)
    {
        _chatInput.SetEnabled(enabled);
        _sendButton.SetEnabled(enabled);
        _micButton.SetEnabled(enabled);
    }

    private void ScrollToBottom()
    {
        // Defer one frame so layout is complete
        _chatScroll.schedule.Execute(() =>
        {
            _chatScroll.scrollOffset = new Vector2(0, float.MaxValue);
        }).ExecuteLater(50);
    }

    // ── WAV Conversion ────────────────────────────────────────────
    private static AudioClip TrimAudioClip(AudioClip clip, int samples)
    {
        float[] data = new float[samples * clip.channels];
        clip.GetData(data, 0);
        AudioClip trimmed = AudioClip.Create("trimmed", samples, clip.channels, clip.frequency, false);
        trimmed.SetData(data, 0);
        return trimmed;
    }

    private static byte[] AudioClipToWav(AudioClip clip)
    {
        float[] samples = new float[clip.samples * clip.channels];
        clip.GetData(samples, 0);

        int    byteCount = samples.Length * 2;
        byte[] wav       = new byte[44 + byteCount];

        // RIFF header
        Encoding.ASCII.GetBytes("RIFF").CopyTo(wav, 0);
        BitConverter.GetBytes(36 + byteCount).CopyTo(wav, 4);
        Encoding.ASCII.GetBytes("WAVE").CopyTo(wav, 8);
        Encoding.ASCII.GetBytes("fmt ").CopyTo(wav, 12);
        BitConverter.GetBytes(16).CopyTo(wav, 16);           // chunk size
        BitConverter.GetBytes((short)1).CopyTo(wav, 20);     // PCM
        BitConverter.GetBytes((short)clip.channels).CopyTo(wav, 22);
        BitConverter.GetBytes(clip.frequency).CopyTo(wav, 24);
        BitConverter.GetBytes(clip.frequency * clip.channels * 2).CopyTo(wav, 28); // byte rate
        BitConverter.GetBytes((short)(clip.channels * 2)).CopyTo(wav, 32);         // block align
        BitConverter.GetBytes((short)16).CopyTo(wav, 34);    // bits per sample
        Encoding.ASCII.GetBytes("data").CopyTo(wav, 36);
        BitConverter.GetBytes(byteCount).CopyTo(wav, 40);

        // PCM data
        int offset = 44;
        foreach (float s in samples)
        {
            short v = (short)Mathf.Clamp(s * 32767f, short.MinValue, short.MaxValue);
            wav[offset++] = (byte)(v & 0xFF);
            wav[offset++] = (byte)((v >> 8) & 0xFF);
        }

        return wav;
    }

    // ── Serializable Data Models ──────────────────────────────────
    [Serializable] private class STTResponse { public string text; }

    [Serializable]
    private class ChatRequest
    {
        public string        model;
        public ChatMessage[] messages;
    }

    [Serializable]
    private class ChatMessage
    {
        public string role;
        public string content;
    }

    [Serializable]
    private class ChatResponse
    {
        public Choice[] choices;
        [Serializable] public class Choice { public ChatMessage message; }
    }
}
